import random
import turtle

def loadings():
    t= turtle.Turtle()
    b = turtle.Turtle()
    a = turtle.Turtle()
    a.ht()
    screen = turtle.Screen()
    screen.setup(width=1000, height=800)
    screen.title("loading")
    screen.bgcolor("darkslategray")
    b.hideturtle()
    b.up()
    b.lt(90)
    b.fd(30)
    b.rt(90)

    t.hideturtle()

    t.up()
    t.bk(275)
    t.down()

    t.fd(550)
    t.rt(90)
    t.fd(26)
    t.rt(90)
    t.fd(550)
    t.rt(90)
    t.fd(26)
    t.rt(90)

    t.up()
    t.fd(10)
    t.rt(90)
    t.fd(6.5)
    t.down()

    a.penup()
    a.goto(0,250)
    a.pendown()
    a.write('راهنما',align='center',font=('Titr',25,"bold"))

    a.penup()
    a.goto(0, 225)
    a.pendown()
    a.write('^ = توان', align='center', font=('Titr', 15, "bold"))

    a.penup()
    a.goto(0, 200)
    a.pendown()
    a.write('/ = تقسیم', align='center', font=('Titr', 15, "bold"))

    a.penup()
    a.goto(0, 175)
    a.pendown()
    a.write('* = ضرب', align='center', font=('Titr', 15, "bold"))

    a.penup()
    a.goto(0, 150)
    a.pendown()
    a.write('- = منها', align='center', font=('Titr', 15, "bold"))

    a.penup()
    a.goto(0, 125)
    a.pendown()
    a.write('+ = جمع', align='center', font=('Titr', 15, "bold"))

    b.write('Loading...',align='center',font=('',10,"bold"))

    for i in range(265):
        t_speed = random.randint(99999999,100000001)
        t.speed(t_speed)
        t.width(3)
        t.fd(13)
        t.lt(90)
        t.fd(1)
        t.lt(90)
        t.fd(13)
        t.rt(90)
        t.fd(1)
        t.rt(90)

    b.clear()
    b.write("finished",align='center',font=('',10,"bold"))
    b.down()
    b.clear()
    t.clear()
    screen.setup(width=500, height=500)
    screen.title("ماشین حساب")
    screen.bgcolor("white")
    a.clear()