from loading import load
from ui_mashin_hesab import UI_mashin_hesab
import turtle
import random

t = turtle.Turtle()
w = turtle.Screen()

def team():
    w = turtle.Screen()
    t.hideturtle()
    w.setup(1000,800)
    w.bgcolor("sienna")
    t.penup()
    t.goto(x=-30,y=300)
    t.pendown()
    t.write(arg='با سلام', font=('Arial', 13, 'bold'))

    t.penup()
    t.goto(x=-280,y=250)
    t.pendown()
    t.write(arg='B1-7:گروه ', font=('Courier', 13, 'bold'))

    t.penup()
    t.goto(x=+140,y=250)
    t.pendown()
    t.write(arg='پروژه : ماشین حساب', font=('Courier', 13, 'bold'))

    t.penup()
    t.goto(x=-280,y=200)
    t.pendown()
    t.write(arg='ما در این پروژه از کتابخانه ی ترتل برای گرافیک استفاده کرده ایم', font=('Courier', 13, 'bold'))

    t.penup()
    t.goto(x=-230,y=150)
    t.pendown()
    t.write(arg='به دلیل اجازه نداشتن به کتابخانه های گرافیکی دیگر', font=('Courier', 13, 'bold'))

    t.penup()
    t.goto(x=-200,y=100)
    t.pendown()
    t.write(arg='نتوانسته ایم گرافیک بهتر را ارائه دهیم', font=('Courier', 13, 'bold'))

    t.penup()
    t.goto(x=-230,y=50)
    t.pendown()
    t.write(arg='ولی همین امر باعث شد تا چالش جدیدی برای ما پیش اید', font=('Courier', 13, 'bold'))

    t.penup()
    t.goto(x=-250,y=0)
    t.pendown()
    t.write(arg='و ما توانستیم جواب حاصل از عملیات (-و+و...) را با اعداد دیگر ', font=('Courier', 13, 'bold'))

    t.penup()
    t.goto(x=-200,y=-50)
    t.pendown()
    t.write(arg='محاسبه کنیم و کمبود گرافیک را جبران کنیم', font=('Courier', 13, 'bold'))

    t.penup()
    t.goto(x=+280,y=-100)
    t.pendown()
    t.write(arg=':اعضای تیم', font=('Courier', 15, 'bold'))

    t.penup()
    t.goto(x=-250,y=-150)
    t.pendown()
    t.write(arg='سینا فرهنگ و ابوالفضل خیری و علی قاسم زاده و علی محمدی ', font=('Titr', 20, 'bold'))

    def back(x, y):
        w.clear()
        background()
        home()

    rect1 = turtle.Turtle()
    rect1.shape("square")
    rect1.color("saddlebrown")
    rect1.penup()
    rect1.shapesize(5, 7)
    rect1.penup()
    rect1.goto(0, -225)
    rect1.onclick(back)
    t.penup()
    t.goto(x=-40, y=-245)
    t.pendown()
    t.write(arg='صفحه قبل', font=('Titr', 20, 'bold'))

def background():
    
    
    turtle.tracer(1,0)


    w.bgcolor("black")
    

    t.color("white")
    
    
    def stars():
        for i in range(5):
            t.fd(10)
            t.right(144)
    
    
    for i in range(100):
    
        x = random.randint(-640, 640)
        y = random.randint(-330, 330)
        

        stars()
        
        t.up()
        
        t.goto(x, y)
        
        t.down()
    
    t.up()
    
    t.goto(0, 170)
    
    t.down()
    

    t.end_fill()

    t.hideturtle()
    

def home():

    wn = turtle.Screen()
    def start(x, y):
        wn.clear()
        load.loadings()
        turtle.tracer(1,0)
        UI_mashin_hesab.UI()
    def about(x, y):
        wn.clear()
        team()


    # ایجاد نمایشگر

    # ایجاد دو مستطیل
    rect1 = turtle.Turtle()
   
    rect1.shape("square")
    rect1.color("dimgray")
    rect1.penup()
    rect1.goto(160,40)
    rect1.shapesize(5, 7)
    rect1.penup()
    rect1.goto(160, 40)
    rect1.onclick(start)

    rect2 = turtle.Turtle()
    rect2.shape("square")
    rect2.color("dimgray")
    rect2.shapesize(5, 7)
    rect2.penup()
    rect2.goto(-160, 40)
    rect2.onclick(about)
    #===========================================================================
    t = turtle.Turtle()
    t.ht()
    t.color("white")
    t.penup()
    t.goto(130,30)
    t.write('شروع', font=('Courier', 20, 'bold'))

    t.color("white")
    t.penup()
    t.goto(-233,30)
    t.write('درباره ما', font=('Courier', 20, 'bold'))
    # #===========================================================================
    t.goto(180,-20)
    t.pendown()
    def semi_circle(col, rad, val):
 
        t.color(col)
    
        t.circle(rad, -180)
    
        t.up()
    
        t.setpos(val, 0)
    
        t.down()
    
        t.right(180)
    t.right(-90)
    t.width(10)
    t.speed(7)
 
    semi_circle('red', 20*(
      1 + 8), -10*(1 + 1))
    turtle.done()  


try:
    background()
    home()
except :
    print("خیلی ممنون که از برنامه ما استفاده کردید")
    