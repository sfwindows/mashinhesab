import turtle
t = turtle.Turtle()
t.ht()
screen = turtle.Screen()
screen.setup(width=500, height=500)
screen.title("ماشین حساب")

# تنظیم صفحه
javab_asle = []
sums = 0 
sum = 0
x = 80
y =170
def tarikhceh():
    global sums
    global sum
    global x
    global y
    s = javab_asle[sums]
    t.write(s, font=('Courier', 20, 'bold'))
    t.backward(20)
    y -= 25
    sums += 1
    if sums == 15:
        tak = turtle.Turtle()
        tak.ht()
        tak.penup()
        tak.goto(50, 210)
        tak.pendown()
        tak.fillcolor("white")
        tak.begin_fill()
        tak.fd(200)
        tak.rt(90)
        tak.fd(410)
        tak.rt(90)
        tak.fd(200)
        tak.rt(90)
        tak.fd(410)
        tak.end_fill()
        tak.penup()
        tak.rt(90)
        tak.goto(80,170)
        x= 80
        y =170

def UI():


 
    global sum
    t.speed(20000000)
    # -----------------------------------------------------------------------
    # نمایش عدد 0
    t.penup()
    t.goto(-240, -240)
    t.pendown()
    t.fillcolor("peachpuff")
    t.goto(-240, -200)
    t.goto(-177.5, -200)
    t.goto(-177.5, -240)
    t.goto(-240, -240)
    t.penup()
    t.pendown()
    t.begin_fill()
    t.goto(-240, -200)
    t.goto(-177.5, -200)
    t.goto(-177.5, -240)
    t.goto(-240, -240)
    t.end_fill()
    t.penup()
    t.goto(-220, -245)
    t.write("0", font=('Courier', 30, 'bold'))


    # نمایش عدد 1
    t.fillcolor("peachpuff")
    t.begin_fill()
    t.penup()
    t.goto(-240, -190)
    t.pendown()
    t.goto(-240, -150)
    t.goto(-177.5, -150)
    t.goto(-177.5, -190)
    t.goto(-240, -190)
    t.end_fill()
    t.penup()
    t.goto(-220, -195)
    t.write("1", font=('Courier', 30, 'bold'))


    # نمایش عدد 4
    t.fillcolor("peachpuff")
    t.begin_fill()
    t.penup()
    t.goto(-240, -140)
    t.pendown()
    t.goto(-240, -100)
    t.goto(-177.5, -100)
    t.goto(-177.5, -140)
    t.goto(-240, -140)
    t.end_fill()
    t.penup()
    t.goto(-220, -145)
    t.write("4", font=('Courier', 30, 'bold'))


    # نمایش عدد 7
    t.fillcolor("peachpuff")
    t.begin_fill()
    t.penup()
    t.goto(-240, -90)
    t.pendown()
    t.goto(-240, -50)
    t.goto(-177.5, -50)
    t.goto(-177.5, -90)
    t.goto(-240, -90)
    t.end_fill()
    t.penup()
    t.goto(-220, -95)
    t.write("7", font=('Courier', 30, 'bold'))


    # نمایش عدد =
    t.fillcolor("peachpuff")
    t.begin_fill()
    t.penup()
    t.goto(-167.5, -240)
    t.pendown()
    t.goto(-167.5, -200)
    t.goto(-105, -200)
    t.goto(-105, -240)
    t.goto(-167.5, -240)
    t.end_fill()
    t.penup()
    t.goto(-147.5, -245)
    t.write("=", font=('Courier', 30, 'bold'))


    # نمایش عدد 2
    t.fillcolor("peachpuff")
    t.begin_fill()
    t.penup()
    t.goto(-167.5, -190)
    t.pendown()
    t.goto(-167.5, -150)
    t.goto(-105, -150)
    t.goto(-105, -190)
    t.goto(-167.5, -190)
    t.end_fill()
    t.penup()
    t.goto(-147.5, -195)
    t.write("2", font=('Courier', 30, 'bold'))


    # نمایش عدد 5
    t.fillcolor("peachpuff")
    t.begin_fill()
    t.penup()
    t.goto(-167.5, -140)
    t.pendown()
    t.goto(-167.5, -100)
    t.goto(-105, -100)
    t.goto(-105, -140)
    t.goto(-167.5, -140)
    t.end_fill()
    t.penup()
    t.goto(-147.5, -145)
    t.write("5", font=('Courier', 30, 'bold'))


    # نمایش عدد 8
    t.fillcolor("peachpuff")
    t.begin_fill()
    t.penup()
    t.goto(-167.5, -90)
    t.pendown()
    t.goto(-167.5, -50)
    t.goto(-105, -50)
    t.goto(-105, -90)
    t.goto(-167.5, -90)
    t.end_fill()
    t.penup()
    t.goto(-147.5, -95)
    t.write("8", font=('Courier', 30, 'bold'))


    # نمایش عدد +
    t.fillcolor("peachpuff")
    t.begin_fill()
    t.penup()
    t.goto(-95, -240)
    t.pendown()
    t.goto(-95, -200)
    t.goto(-32.5, -200)
    t.goto(-32.5, -240)
    t.goto(-95, -240)
    t.end_fill()
    t.penup()
    t.goto(-75, -245)
    t.write("+", font=('Courier', 30, 'bold'))


    # نمایش عدد 3
    t.fillcolor("peachpuff")
    t.begin_fill()
    t.penup()
    t.goto(-95, -190)
    t.pendown()
    t.goto(-95, -150)
    t.goto(-32.5, -150)
    t.goto(-32.5, -190)
    t.goto(-95, -190)
    t.end_fill()
    t.penup()
    t.goto(-75, -195)
    t.write("3", font=('Courier', 30, 'bold'))


    # نمایش عدد 6
    t.fillcolor("peachpuff")
    t.begin_fill()
    t.penup()
    t.goto(-95, -140)
    t.pendown()
    t.goto(-95, -100)
    t.goto(-32.5, -100)
    t.goto(-32.5, -140)
    t.goto(-95, -140)
    t.end_fill()
    t.penup()
    t.goto(-75, -145)
    t.write("6", font=('Courier', 30, 'bold'))


    # نمایش عدد 9
    t.fillcolor("peachpuff")
    t.begin_fill()
    t.penup()
    t.goto(-95, -90)
    t.pendown()
    t.goto(-95, -50)
    t.goto(-32.5, -50)
    t.goto(-32.5, -90)
    t.goto(-95, -90)
    t.end_fill()
    t.penup()
    t.goto(-75, -95)
    t.write("9", font=('Courier', 30, 'bold'))


    # نمایش عدد -
    t.fillcolor("peachpuff")
    t.begin_fill()
    t.penup()
    t.goto(-22.5, -240)
    t.pendown()
    t.goto(-22.5, -200)
    t.goto(40, -200)
    t.goto(40, -240)
    t.goto(-22.5, -240)
    t.end_fill()
    t.penup()
    t.goto(-0.5, -245)
    t.write("-", font=('Courier', 30, 'bold'))


    # نمایش عدد *
    t.fillcolor("peachpuff")
    t.begin_fill()
    t.penup()
    t.goto(-22.5, -190)
    t.pendown()
    t.goto(-22.5, -150)
    t.goto(40, -150)
    t.goto(40, -190)
    t.goto(-22.5, -190)
    t.end_fill()
    t.penup()
    t.goto(-2.5, -202.5)
    t.write("*", font=('Courier', 35, 'bold'))


    # نمایش عدد /
    t.fillcolor("peachpuff")
    t.begin_fill()
    t.penup()
    t.goto(-22.5, -140)
    t.pendown()
    t.goto(-22.5, -100)
    t.goto(40, -100)
    t.goto(40, -140)
    t.goto(-22.5, -140)
    t.end_fill()
    t.penup()
    t.goto(-0.5, -140)
    t.write("/", font=('Courier', 25, 'bold'))
    #

    # نمایش عدد ^
    t.fillcolor("peachpuff")
    t.begin_fill()
    t.penup()
    t.goto(-22.5, -90)
    t.pendown()
    t.goto(-22.5, -50)
    t.goto(40, -50)
    t.goto(40, -90)
    t.goto(-22.5, -90)
    t.end_fill()
    t.penup()
    t.goto(-0.5, -95)
    t.write("^", font=('Courier', 30, 'bold'))

    # ------------------------------------------------------------------------------
    b = turtle.Turtle()
    b.ht()
    b.penup()
    b.goto(-240, -40)
    b.pendown()
    b.fillcolor("peachpuff")
    b.begin_fill()
    b.goto(-240, 240)
    b.goto(40, 240)
    b.goto(40, -40)
    b.goto(-240, -40)
    b.end_fill()
    b.penup()


    # ------------------------------------------------------------------
    # صفخه تاریخچه
    t.penup()
    t.goto(50, 250)
    t.pendown()
    t.goto(50, -250)
    t.penup()
    t.goto(90, 215)
    t.write("تاریخچه", font=('Courier', 20, 'bold'))
    t.goto(250, 210)
    t.pendown()
    t.goto(50, 210)
    t.penup()
    t.goto(60, 180)
    # --------------------------------------------------
    # لوگو
    t.goto(x=50, y=-200)
    t.down()
    t.fd(200)
    t.up()
    t.goto(x=125, y=-230)
    t.write("B1-7", font=('Calisto MT', 15, 'bold'))
    # -----------------------------------------------------
    
    def formol():
        # باکس اول  
                global sum
                global javab
                t.goto(x=-200, y=200)
                while True:
                    try:
                        number=float(screen.textinput("number","یک عدد وارد کنید"))
                        t.write(arg=number,font=('Courier',13, 'bold'))
                        break
                    except ValueError:
                        t.write("این یک عدد نیست. لطفا دوباره تلاش کنید.")
                        t.undo()
            # ---------------------------------------------------------------------
            # باکس دوم
                t.goto(x=-225, y=175)
                while True:
                    try:
                        alamat = screen.textinput("alamat","یک علامت وارد کنید")
                        if alamat == "^":
                            t.write(arg=alamat,font=('Courier', 15, 'bold'))
                            break
                        elif alamat == "/":
                            t.write(arg=alamat, font=('Courier', 15, 'bold'))
                            break
                        elif alamat == "*":
                            t.write(arg=alamat, font=('Courier', 15, 'bold'))
                            break
                        elif alamat == "-":
                            t.write(arg=alamat, font=('Courier', 15, 'bold'))
                            break
                        elif alamat == "+":
                            t.write(arg=alamat, font=('Courier', 15, 'bold'))
                            break
                    except ValueError:
                        t.write("این یک علامت نیست. لطفا دوباره تلاش کنید.")
                        t.undo()

            # -------------------------------------------------------------
            # باکس سوم
                t.goto(x=-200, y=150)
                while True:
                    try:
                        number2=float(screen.textinput("number2","یک عدد وارد کنید"))
                        t.write(arg=number2,font=('Courier', 13, 'bold'))
                        break
                    except ValueError:
                        t.write("این یک عدد نیست. لطفا دوباره تلاش کنید.")
                        t.undo()
            # --------------------------------------------------------------------
            # خط کسری

                t.goto(x=-220, y=135)
                t.down()
                t.fd(80)
                t.up()

            # --------------------------------------------------------------------
            # جواب
                t.goto(x=-200, y=110)
                if alamat == "^":
                    javab = (number ** number2)
                    t.write(arg=javab,font=('Courier', 13, 'bold'))
                    t.goto(x,y)
                    javab_asle.append(javab)

                    tarikhceh()

                elif alamat == "/":
                    javab = (number / number2)
                    t.write(arg=javab, font=('Courier', 13, 'bold'))
                    t.goto(x,y)
                    javab_asle.append(javab)

                    tarikhceh()

                elif alamat == "*":
                    javab = (number * number2)
                    t.write(arg=javab, font=('Courier', 13, 'bold'))
                    t.goto(x,y)
                    javab_asle.append(javab)
                    tarikhceh()
                elif alamat == "-":
                    javab = (number - number2)
                    t.write(arg=javab, font=('Courier', 13, 'bold'))
                    t.goto(x,y)
                    javab_asle.append(javab)

                    tarikhceh()
                elif alamat == "+":
                    javab = (number + number2)
                    t.write(arg=javab, font=('Courier', 13, 'bold'))
                    t.goto(x,y)
                    javab_asle.append(javab)

                    tarikhceh()


            # --------------------------------------------------------------------------------------------------------------------------------------


            # -------------------------------------------------------------------
            # اثبات

                t.goto(x=-200, y=50)

                if alamat == "^":
                    esbat = (number ** number2)
                    t.write(arg=esbat, font=('Courier', 13, 'bold'))
                elif alamat == "/":
                    esbat = (number / number2)
                    t.write(arg=esbat, font=('Courier', 13, 'bold'))
                elif alamat == "*":
                    esbat = (number * number2)
                    t.write(arg=esbat, font=('Courier', 13, 'bold'))
                elif alamat == "-":
                    esbat = (number - number2)
                    t.write(arg=esbat, font=('Courier', 13, 'bold'))
                elif alamat == "+":
                    esbat = (number + number2)
                    t.write(arg=esbat, font=('Courier', 13, 'bold'))
                # علامت

                t.penup()
                t.goto(x=-225, y=25)
                t.pendown()

                if alamat == "/":
                    t.write(arg="*",font=('Courier', 15, 'bold'))

                elif alamat == "*":
                    t.write(arg="/",font=('Courier', 15, 'bold'))

                elif alamat == "-":
                    t.write(arg="+", font=('Courier', 15, 'bold'))

                elif alamat == "+":
                    t.write(arg="-", font=('Courier', 15, 'bold'))

                t.penup()
                t.goto(x=-200, y=0)
                t.pendown()
                t.write(arg=number2, font=('Courier', 13, 'bold'))

                t.penup()
                t.goto(x=-220, y=-15)
                t.pendown()
                t.fd(85)

                t.penup()
                t.goto(x=-200, y=-35)
                t.pendown()

                t.penup()

                if alamat == "^":
                    t.write(arg="(این علامت اثبات ندارد)", font=('Courier', 13, 'bold'))

                elif alamat == "/":
                    javabesbat = javab * number2
                    t.write(arg=javabesbat,font=('Courier', 13, 'bold'))

                elif alamat == "*":
                    javabesbat = javab / number2
                    t.write(arg=javabesbat,font=('Courier', 13, 'bold'))
 
                elif alamat == "-":
                    javabesbat = javab + number2
                    t.write(arg=javabesbat, font=('Courier', 13, 'bold'))

                elif alamat == "+":
                    javabesbat = javab - number2
                    t.write(arg=javabesbat, font=('Courier', 13, 'bold'))



                t.penup()
                # -------------------------------------------------------------------
            # ----------------------------------------------------------------------
            # ----------------------------------------------------------------------

    formol()
    
    
    def add_next():
        global sum
        answer1 = screen.textinput("!!!سوال", "?ایا میخواهی عدد جدیدی را با جواب محاسبه کنی")
        if answer1 is None or answer1.lower().startswith("n"):
            screen.clear()
            answer = screen.textinput("!!!سوال", "?ایا میخواهی عدد جدیدی را محاسبه کنی")
            if answer is None or answer.lower().startswith("n"):
                screen.clear()
                print("خیلی ممنون که از برنامه ما استفاده کردید")
                screen.clear()
                screen.bye()
            elif answer is None or answer.lower().startswith("ن"):
                screen.clear()
                print("خیلی ممنون که از برنامه ما استفاده کردید")
                screen.clear()
                screen.bye()
            else:
                try:
                    screen.clear()
                    UI()
                except ValueError:
                    t.write("لطفا دوباره تلاش کنید.")
                    t.undo()
        elif answer1 is None or answer1.lower().startswith("ن"):
            screen.clear()
            answer = screen.textinput("!!!سوال", "?ایا میخواهی عدد جدیدی را محاسبه کنی")
            if answer is None or answer.lower().startswith("n"):
                screen.clear()
                print("خیلی ممنون که از برنامه ما استفاده کردید")
                screen.clear()
                screen.bye()
            elif answer is None or answer.lower().startswith("ن"):
                screen.clear()
                print("خیلی ممنون که از برنامه ما استفاده کردید")
                screen.clear()
                screen.bye()
            else:
                try:
                    screen.clear()
                    UI()
                except ValueError:
                    t.write("لطفا دوباره تلاش کنید.")
                    t.undo()
        else:
                b.ht()
                b.penup()
                b.goto(-240, -40)
                b.pendown()
                b.fillcolor("peachpuff")
                b.begin_fill()
                b.goto(-240, 240)
                b.goto(40, 240)
                b.goto(40, -40)
                b.goto(-240, -40)
                b.end_fill()
                b.penup()

                t.goto(x=-200, y=200)
                number = javab_asle[sum]
                sum +=1

                t.write(arg=number, font=('Courier', 13, 'bold'))

                t.goto(x=-225, y=175)
                while True:
                    try:
                        alamat = screen.textinput("alamat", 'یک علامت وارد کنید')

                        if alamat == "^":
                            t.write(arg=alamat, font=('Courier', 15, 'bold'))
                            break
                        elif alamat == "/":
                            t.write(arg=alamat, font=('Courier', 15, 'bold'))
                            break
                        elif alamat == "*":
                            t.write(arg=alamat, font=('Courier', 15, 'bold'))
                            break
                        elif alamat == "-":
                            t.write(arg=alamat, font=('Courier', 15, 'bold'))
                            break
                        elif alamat == "+":
                            t.write(arg=alamat, font=('Courier', 15, 'bold'))
                            break
                    except ValueError:
                        t.write("این یک علامت نیست. لطفا دوباره تلاش کنید.")
                        t.undo()

                # -------------------------------------------------------------
                # باکس سوم
                t.goto(x=-200, y=150)
                while True:
                    try:
                        number2 = float(screen.textinput("number2", "یک عدد وارد کنید"))
                        t.write(arg=number2, font=('Courier', 13, 'bold'))
                        break
                    except ValueError:
                        t.write("این یک عدد نیست. لطفا دوباره تلاش کنید.")
                        t.undo()
                # --------------------------------------------------------------------
                # خط کسری

                b.goto(x=-220, y=135)
                b.down()
                b.fd(80)
                b.up()

                # --------------------------------------------------------------------
                # جواب
                t.goto(x=-200, y=110)
                if alamat == "^":
                    javab = (number ** number2)
                    t.write(arg=javab, font=('Courier', 13, 'bold'))
                    t.goto(x,y)
                    javab_asle.append(javab)
                    tarikhceh()
                elif alamat == "/":
                    javab = (number / number2)
                    t.write(arg=javab, font=('Courier', 13, 'bold'))
                    t.goto(x,y)
                    javab_asle.append(javab)

                    tarikhceh()
                elif alamat == "*":
                    javab = (number * number2)
                    t.write(arg=javab, font=('Courier', 13, 'bold'))
                    t.goto(x,y)
                    javab_asle.append(javab)

                    tarikhceh()
                elif alamat == "-":
                    javab = (number - number2)
                    t.write(arg=javab, font=('Courier', 13, 'bold'))
                    t.goto(x,y)
                    javab_asle.append(javab)
                    tarikhceh()
                elif alamat == "+":
                    javab = (number + number2)
                    t.write(arg=javab, font=('Courier', 13, 'bold'))
                    t.goto(x,y)
                    javab_asle.append(javab)
                    tarikhceh()

                # --------------------------------------------------------------------------------------------------------------------------------------

                # -------------------------------------------------------------------

                t.goto(x=-200, y=50)

                if alamat == "^":
                    esbat = (number ** number2)
                    t.write(arg=esbat, font=('Courier', 13, 'bold'))
                elif alamat == "/":
                    esbat = (number / number2)
                    t.write(arg=esbat, font=('Courier', 13, 'bold'))
                elif alamat == "*":
                    esbat = (number * number2)
                    t.write(arg=esbat, font=('Courier', 13, 'bold'))
                elif alamat == "-":
                    esbat = (number - number2)
                    t.write(arg=esbat, font=('Courier', 13, 'bold'))
                elif alamat == "+":
                    esbat = (number + number2)
                    t.write(arg=esbat, font=('Courier', 13, 'bold'))
                # علامت

                t.penup()
                t.goto(x=-225, y=25)
                t.pendown()


                if alamat == "/":
                    t.write(arg="*", font=('Courier', 15, 'bold'))

                elif alamat == "*":
                    t.write(arg="/", font=('Courier', 15, 'bold'))

                elif alamat == "-":
                    t.write(arg="+", font=('Courier', 15, 'bold'))

                elif alamat == "+":
                    t.write(arg="-", font=('Courier', 15, 'bold'))

                t.penup()
                t.goto(x=-200, y=0)
                t.pendown()
                t.write(arg=number2, font=('Courier', 13, 'bold'))

                t.penup()
                t.goto(x=-220, y=-15)
                t.pendown()
                t.fd(85)

                t.penup()
                t.goto(x=-200, y=-35)
                t.pendown()

                t.penup()

                if alamat == "^":
                    t.write(arg="(این علامت اثبات ندارد)", font=('Courier', 13, 'bold'))

                elif alamat == "/":
                    javabesbat = javab * number2
                    t.write(arg=javabesbat, font=('Courier', 13, 'bold'))

                elif alamat == "*":
                    javabesbat = javab / number2
                    t.write(arg=javabesbat, font=('Courier', 13, 'bold'))

                elif alamat == "-":
                    javabesbat = javab + number2
                    t.write(arg=javabesbat, font=('Courier', 13, 'bold'))
   
                elif alamat == "+":
                    javabesbat = javab - number2
                    t.write(arg=javabesbat, font=('Courier', 13, 'bold'))

                # --------------------------------------------------------------------------------------------------------------------------------------
                

                add_next()
                # -------------------------------------------------------------------
                # ----------------------------------------------------------------------
                # ----------------------------------------------------------------------





    add_next()